docker stop operationservice
docker rm operationservice
docker rmi operationservice


