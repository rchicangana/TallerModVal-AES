docker stop intermediateroutingservice
docker rm intermediateroutingservice
docker rmi intermediateroutingservice


